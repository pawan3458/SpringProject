package com.project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootWebProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootWebProjectApplication.class, args);
	}

}
